package util.optimization;

public interface Constraint {

    public boolean valid(double[] x);

}
