package util.optimization;

public interface Function {

    public double value(double[] x);

}
