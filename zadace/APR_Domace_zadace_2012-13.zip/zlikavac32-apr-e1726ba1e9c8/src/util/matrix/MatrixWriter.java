package util.matrix;

public interface MatrixWriter {

    public boolean write(Matrix m);

}
