package util.matrix;

public class ZeroPivotException extends RuntimeException {

    public ZeroPivotException() { super(); }

}
