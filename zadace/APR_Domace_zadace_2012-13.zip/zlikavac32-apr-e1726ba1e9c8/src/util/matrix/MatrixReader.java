package util.matrix;

public interface MatrixReader {

    public Matrix read();

}
