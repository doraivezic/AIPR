package util.matrix;

public class MatrixDimensionException extends RuntimeException {

    public MatrixDimensionException(String msg) { super(msg); }

}
