package util.matrix;

public interface Substitution {

    public Matrix substitute(Matrix f, Matrix s);

}
