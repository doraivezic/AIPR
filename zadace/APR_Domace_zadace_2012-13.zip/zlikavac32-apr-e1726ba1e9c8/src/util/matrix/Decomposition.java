package util.matrix;

public interface Decomposition {

    public void decompose(Matrix m);;

}
